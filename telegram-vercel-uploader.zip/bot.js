const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'; // Ganti
const VERCEL_TOKEN = 'YOUR_VERCEL_API_TOKEN';     // Ganti
const PROJECT_NAME = 'telegram-upload-vercel';    // Nama project Vercel

const bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendPhoto(chatId, 'welcome.jpg', {
    caption: "👋 Selamat datang di *Bot Deploy Vercel*\n\nKirim file `index.html` kamu untuk langsung dideploy ke HTTPS!",
    parse_mode: "Markdown"
  });
});

bot.on('document', async (msg) => {
  const chatId = msg.chat.id;
  const fileId = msg.document.file_id;
  const fileName = msg.document.file_name || 'index.html';

  if (!fileName.endsWith('.html')) {
    return bot.sendMessage(chatId, "❌ Hanya menerima file `.html`!");
  }

  try {
    const file = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${TELEGRAM_TOKEN}/${file.file_path}`;
    const localPath = path.join(__dirname, 'index.html');
    const response = await axios.get(fileUrl);
    fs.writeFileSync(localPath, response.data);

    bot.sendMessage(chatId, "🚀 Memulai deploy ke Vercel...");

    const htmlContent = fs.readFileSync(localPath, 'utf8');

    const deploy = await axios.post(
      'https://api.vercel.com/v13/deployments',
      {
        name: PROJECT_NAME,
        files: [
          {
            file: 'index.html',
            data: htmlContent
          }
        ],
        target: 'production'
      },
      {
        headers: {
          Authorization: `Bearer ${VERCEL_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const url = deploy.data.url;
    bot.sendMessage(chatId, `✅ Deploy sukses!\n\nURL: https://${url}`);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ Gagal deploy: " + err.message);
  }
});
